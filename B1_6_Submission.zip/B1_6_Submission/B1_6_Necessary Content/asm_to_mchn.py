# Opcode and register mappings
sequence = 'AMEDOFNJBKCHPLIG'
opcode_map = {sequence[i]: format(i, '04b') for i in range(len(sequence))}

register_map = {
    '$zero': '0000', '$t0': '0111', '$t1': '0001', '$t2': '0010',
    '$t3': '0011', '$t4': '0100', '$sp': '0110'
}

instruction_ids = {
    'add': 'A', 'addi': 'B', 'sub': 'C', 'subi': 'D',
    'and': 'E', 'andi': 'F', 'or': 'G', 'ori': 'H',
    'sll': 'I', 'srl': 'J', 'nor': 'K', 'sw': 'L',
    'lw': 'M', 'beq': 'N', 'bneq': 'O', 'j': 'P'
}


def preprocess_labels(assembly_code):
    """
    Preprocesses assembly code to extract label addresses.
    Returns a dictionary of labels and their corresponding addresses.
    """
    labels = {}
    processed_code = []
    address = 0

    for line in assembly_code:
        if ':' in line:  # Check if the line contains a label
            label, instruction = line.split(':', 1)
            labels[label.strip()] = address
            if instruction.strip():  # Add the remaining instruction
                processed_code.append(instruction.strip())
        else:
            processed_code.append(line.strip())
        address += 1
        
    
    return labels, processed_code


def twos_complement(value, bit_width):
    """
    Converts a signed integer into its two's complement binary representation.
    """
    if value < 0:
        value = (1 << bit_width) + value
    return format(value, f'0{bit_width}b')


def convert_to_machine_code_with_labels(assembly_code):
    """
    Converts assembly code to machine code, including support for labels.
    """
    labels, processed_code = preprocess_labels(assembly_code)
    machine_codes = []
    print(labels)
    for line_number, line in enumerate(processed_code):
        parts = line.replace(',', '').split()
        instruction = parts[0].lower()
        if instruction not in instruction_ids:
            raise ValueError(f"Unknown instruction: {instruction}")

        opcode_id = instruction_ids[instruction]
        opcode = opcode_map[opcode_id]

        if opcode_id in 'ACGKE':  # R-type
            _, rd, rs, rt = parts
            rd_bin = register_map[rd]
            rs_bin = register_map[rs]
            rt_bin = register_map[rt]
            shamt = '0000'
            machine_code = f"{opcode}{rs_bin}{rt_bin}{rd_bin}{shamt}"

        elif opcode_id in 'BFHILMNDJO':  # I-type
            if opcode_id in ['B', 'F', 'H', 'I', 'D', 'J']:  # addi, andi, ori, sll, subi, srl
                _, rt, rs, imm = parts
            elif opcode_id in ['L', 'M']:  # sw, lw
                _, rt, imm_rs = parts
                rt, rs, imm = rt, imm_rs.split('(')[1][:-1], imm_rs.split('(')[0][:]
            else:  # beq, bneq
                _, rs, rt, imm = parts

            rs_bin = register_map[rs]
            rt_bin = register_map[rt]

            if imm.lstrip('-').isdigit():  # Immediate value (positive or negative)
                imm_bin = twos_complement(int(imm), 8)
            elif imm in labels:  # Label reference
                imm_bin = twos_complement(labels[imm] - (line_number + 1), 8)  # PC-relative addressing
            else:
                raise ValueError(f"Unknown label or immediate: {imm}")

            machine_code = f"{opcode}{rs_bin}{rt_bin}{imm_bin}"

        elif opcode_id == 'P':  # J-type
            _, target = parts
            if target.isdigit():  # Immediate address
                target_bin = twos_complement(int(target), 8)
            elif target in labels:  # Label reference
                target_bin = twos_complement(labels[target], 8)
            else:
                raise ValueError(f"Unknown label or target: {target}")

            machine_code = f"{opcode}{target_bin}00000000"

        else:
            raise ValueError(f"Unsupported instruction ID: {opcode_id}")

        machine_codes.append(machine_code)

    return machine_codes


def write_to_file(machine_codes, file_name="machine_code.txt"):
    """
    Writes machine code to a file in hex format.
    """
    with open(file_name, "w") as file:
        file.write("v2.0 raw\n")
        for binary_code in machine_codes:
            hex_code = f"{int(binary_code, 2):05X}"  # Ensure 5 hexadecimal digits
            file.write(hex_code + " ")



def clean_assembly_code_with_labels(input_file, output_file):
    with open(input_file, 'r') as infile:
        lines = infile.readlines()

    # Initialize a list to store cleaned lines
    cleaned_lines = []
    label = None

    for line in lines:
        # Strip leading/trailing whitespace and ignore empty lines or comment lines
        line = line.strip()

        if not line or line.startswith('#'):
            continue

        # Check if the line ends with a colon, indicating it's a label
        if line.endswith(':'):
            if label:
                # If we have a label to append, add it to the next instruction
                cleaned_lines[-1] = f"{label} {cleaned_lines[-1]}"
            # Store the label to append to the next line
            label = line
            continue
        else:
            # Add the instruction line
            if label:
                cleaned_lines.append(f"{label} {line}")
                label = None  # Reset the label after appending
            else:
                cleaned_lines.append(line)

    # Write the cleaned lines to the output file
    with open(output_file, 'w') as outfile:
        for line in cleaned_lines:
            outfile.write(line + '\n')


def read_assembly_code(file_name="assembly_code.txt"):
    """
    Reads assembly code from a file and returns it as a list of lines.
    """
    with open(file_name, "r") as file:
        return [line.strip() for line in file if line.strip()]


# Main Execution
clean_assembly_code_with_labels("assembly_code.txt", "cleaned_assembly_code.txt")
assembly_code = read_assembly_code("cleaned_assembly_code.txt")
machine_code_output = convert_to_machine_code_with_labels(assembly_code)
write_to_file(machine_code_output)

# Display results
print("Assembly Code -> Machine Code:")
for asm, mc in zip(assembly_code, machine_code_output):
    print(f"{asm} -> {mc}")
    

